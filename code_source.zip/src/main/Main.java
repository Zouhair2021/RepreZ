package main;

import com.zouhair.RepNombres;

public class Main
{
    public static void main(String[] args)
    {

        RepNombres repNombres = new RepNombres();
        repNombres.setVisible(true);
    }
}